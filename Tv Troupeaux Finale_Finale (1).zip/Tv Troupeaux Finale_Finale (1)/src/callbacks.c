#include <gtk/gtk.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "troupeau.h"

void
on_retour_vers_menu_troupeau_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_troupeaux, *fenetre_ajout_troupeau;

	fenetre_ajout_troupeau=lookup_widget(objet,"fenetre_ajout_troupeau");
	

	gtk_widget_destroy(fenetre_ajout_troupeau);
	menu_troupeaux=create_menu_troupeaux();
	gtk_widget_show(menu_troupeaux);
}

void
on_ajouter_troupeau_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
Troupeau t;

GtkWidget *input1, *input2, *input3, *input4, *input5, *input6;
GtkWidget *fenetre_ajout_troupeau;

fenetre_ajout_troupeau=lookup_widget(objet,"fenetre_ajout_troupeau");

input1=lookup_widget(objet,"identifiantid"); 
input2=lookup_widget(objet,"type");
input3=lookup_widget(objet,"dateajout");
input4=lookup_widget(objet,"sexe");
input5=lookup_widget(objet,"poids");


strcpy(t.IDtroupeau,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(t.Typetroupeau,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(t.Datetroupeau,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(t.Sexetroupeau,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(t.Poidstroupeau,gtk_entry_get_text(GTK_ENTRY(input5)));


ajouter_troupeau(t);
}

void
on_afficher_troupeau_clicked            (GtkWidget        *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout_troupeau;
GtkWidget *fenetre_afficher_troupeau;
GtkWidget *treeview1_troupeau;

fenetre_ajout_troupeau=lookup_widget(objet,"fenetre_ajout_troupeau");

gtk_widget_destroy(fenetre_ajout_troupeau);
fenetre_afficher_troupeau=lookup_widget(objet,"fenetre_afficher_troupeau");
fenetre_afficher_troupeau=create_fenetre_afficher_troupeau();

gtk_widget_show(fenetre_afficher_troupeau);

treeview1_troupeau=lookup_widget(fenetre_afficher_troupeau,"treeview1_troupeau");

afficher_troupeau(treeview1_troupeau);
}

void
on_treeview1_troupeau_row_activated    (GtkTreeView     *treeview1_troupeau,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* identifiantid;
	gchar* type;
	gchar* dateajout;
	gchar* sexe;
	gchar* poids;
	
	Troupeau t;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview1_troupeau);

	if(gtk_tree_model_get_iter(model, &iter, path))
	{
		//obtention des valeurs de la ligne selectionnée
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiantid, 1, &type, 2, &dateajout, 3, &sexe, 4, &poids,-1);
		//copie des valeurs dans la variable t de type troupeau pour passer a la fonction de suppression 
		strcpy(t.IDtroupeau,identifiantid);
		strcpy(t.Typetroupeau,type);
		strcpy(t.Datetroupeau,dateajout);
		strcpy(t.Sexetroupeau,sexe);
		strcpy(t.Poidstroupeau,poids);
		
		//appel de la fonction de suppression
		supprimer_troupeau(t);
		//mise a jour de l'affichage de la treeview
		afficher_troupeau(treeview1_troupeau);
	}



}

void
on_retour_troupeau_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *menu_troupeaux, *fenetre_afficher_troupeau;

	fenetre_afficher_troupeau=lookup_widget(objet,"fenetre_afficher_troupeau");
	

	gtk_widget_destroy(fenetre_afficher_troupeau);
	menu_troupeaux=create_menu_troupeaux();
	gtk_widget_show(menu_troupeaux);
}


void
on_afficher_troupeaux_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_troupeaux;
GtkWidget *fenetre_afficher_troupeau;
GtkWidget *treeview1_troupeau;

menu_troupeaux=lookup_widget(objet,"menu_troupeaux");
gtk_widget_destroy(menu_troupeaux);

fenetre_afficher_troupeau=lookup_widget(objet,"fenetre_afficher_troupeau");
fenetre_afficher_troupeau=create_fenetre_afficher_troupeau();

gtk_widget_show(fenetre_afficher_troupeau);

treeview1_troupeau=lookup_widget(fenetre_afficher_troupeau,"treeview1_troupeau");

afficher_troupeau(treeview1_troupeau);
}

void
on_ajouter_troupeaux_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_troupeaux, *fenetre_ajout_troupeau;

	menu_troupeaux=lookup_widget(objet,"menu_troupeaux");
	

	gtk_widget_destroy(menu_troupeaux);
	fenetre_ajout_troupeau=create_fenetre_ajout_troupeau();
	gtk_widget_show(fenetre_ajout_troupeau);
}

void
on_chercher_troupeaux_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_troupeaux, *fenetre_rechercher_troupeau;

	menu_troupeaux=lookup_widget(objet,"menu_troupeaux");
	

	gtk_widget_destroy(menu_troupeaux);
	fenetre_rechercher_troupeau=create_fenetre_rechercher_troupeau();
	gtk_widget_show(fenetre_rechercher_troupeau);
}

void
on_supprimer_troupeaux_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_troupeaux, *fenetre_supprimer_troupeau;

	menu_troupeaux=lookup_widget(objet,"menu_troupeaux");
	

	gtk_widget_destroy(menu_troupeaux);
	fenetre_supprimer_troupeau=create_fenetre_supprimer_troupeau();
	gtk_widget_show(fenetre_supprimer_troupeau);
}

void
on_modifier_troupeaux_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_troupeaux, *fenetre_modifier_troupeau;

	menu_troupeaux=lookup_widget(objet,"menu_troupeaux");
	

	gtk_widget_destroy(menu_troupeaux);
	fenetre_modifier_troupeau=create_fenetre_modifier_troupeau();
	gtk_widget_show(fenetre_modifier_troupeau);

}

void
on_rechercher_troupeau_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *id,*sortie;
char Id[20];
FILE *f=NULL;
	char chid[20];
	char chtype[20];
	char chdate[20];
	char chsexe[20];
	char chpoids[20];
int trouv=-1;


id = lookup_widget (objet, "rech_id_troupeau");
strcpy(Id, gtk_entry_get_text(GTK_ENTRY(id)));


f=fopen("troupeaux.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s \n",chid,chtype,chdate,chsexe,chpoids)!=EOF)
{

if 	(strcmp(chid,Id)==0)
{	strcat(chtype," ");
	strcat(chtype,chsexe);
	strcat(chtype," ");
	strcat(chtype,chpoids);
sortie = lookup_widget(objet, "label19");
gtk_label_set_text(GTK_LABEL(sortie),chtype);
trouv=1;
}
}
if (trouv!=1)
{
sortie = lookup_widget(objet, "label19");
gtk_label_set_text(GTK_LABEL(sortie),"Id n'existe pas");
}
}
}

void
on_retour_menu1_troupeau_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_troupeaux, *fenetre_rechercher_troupeau;

	fenetre_rechercher_troupeau=lookup_widget(objet,"fenetre_rechercher_troupeau");
	

	gtk_widget_destroy(fenetre_rechercher_troupeau);
	menu_troupeaux=create_menu_troupeaux();
	gtk_widget_show(menu_troupeaux);
}

void
on_supprimer_troupeau_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *id,*sortie;
char Id[20];

int trouv;
id = lookup_widget (objet, "supp_id_troupeau");

strcpy(Id, gtk_entry_get_text(GTK_ENTRY(id)));
trouv=Chercher_troupeau (Id);

if (trouv==1)
{
Supprimer_troupeau(Id);
sortie = lookup_widget(objet, "label23");
gtk_label_set_text(GTK_LABEL(sortie),"troupeau supprimé avec succée!");
//printf("\n troupeau supprimé avec succée!");
}
else 
{
sortie = lookup_widget(objet, "label23");
gtk_label_set_text(GTK_LABEL(sortie),"Id introuvable!");

}
}

void
on_retour_menu2_troupeau_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_supprimer_troupeau, *menu_troupeaux;

	fenetre_supprimer_troupeau=lookup_widget(objet,"fenetre_supprimer_troupeau");
	

	gtk_widget_destroy(fenetre_supprimer_troupeau);
	menu_troupeaux=create_menu_troupeaux();
	gtk_widget_show(menu_troupeaux);
}

void
on_retour_menu3_troupeau_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modifier_troupeau, *menu_troupeaux;

	fenetre_modifier_troupeau=lookup_widget(objet,"fenetre_modifier_troupeau");
	

	gtk_widget_destroy(fenetre_modifier_troupeau);
	menu_troupeaux=create_menu_troupeaux();
	gtk_widget_show(menu_troupeaux);
}

void
on_modifier_troupeau_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *id,*sortie;
GtkWidget *modifier_troupeau, *modification_troupeau;
char Id[20];

int trouv;
id = lookup_widget (objet, "modif_id_troupeau");

strcpy(Id, gtk_entry_get_text(GTK_ENTRY(id)));
trouv=Chercher_troupeau (Id);

if (trouv==1)
{
sortie = lookup_widget(objet, "label37");
gtk_label_set_text(GTK_LABEL(sortie),"troupeau trouvée!");
modifier_troupeau=lookup_widget(objet,"modifier_troupeau");
	

	//gtk_widget_destroy(modifier_troupeau);
	modification_troupeau=create_modification_troupeau();
	gtk_widget_show(modification_troupeau);
}
else 
{
sortie = lookup_widget(objet, "label37");
gtk_label_set_text(GTK_LABEL(sortie),"Id introuvable!");

}
}

void
on_retour_menu4_troupeau_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *modification_troupeau, *menu_troupeaux;

	modification_troupeau=lookup_widget(objet,"modification_troupeau");
	

	gtk_widget_destroy(modification_troupeau);
	menu_troupeaux=create_menu_troupeaux();
	gtk_widget_show(menu_troupeaux);
}


void
on_modifier_confirmer_troupeau_clicked (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *id;
GtkWidget *input1, *input2, *input3, *input4, *input5;      //,chid,chtype,chdate,chsexe,chpoids//
	char Id[20];
	char chid[20];
	char chtype[20];
	char chdate[20];
	char chsexe[20];
	char chpoids[20];
FILE *f=NULL;
FILE *p=NULL;


id = lookup_widget (objet, "modif2_id_troupeau");
strcpy(Id, gtk_entry_get_text(GTK_ENTRY(id)));

f=fopen("troupeaux.txt","r");
p=fopen("temp.txt","w");
if(f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s \n",chid,chtype,chdate,chsexe,chpoids)!=EOF)
{
if (strcmp(chid,Id)==0)
{
input1=lookup_widget(objet,"nvid"); 
input2=lookup_widget(objet,"nvtype");
input3=lookup_widget(objet,"nvdate");
input4=lookup_widget(objet,"nvsexe");
input5=lookup_widget(objet,"nvpoids");


strcpy(chid,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(chtype,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(chdate,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(chsexe,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(chpoids,gtk_entry_get_text(GTK_ENTRY(input5)));

fprintf(p,"%s %s %s %s %s \n",chid,chtype,chdate,chsexe,chpoids);
}
else
fprintf(p,"%s %s %s %s %s \n",chid,chtype,chdate,chsexe,chpoids);
}
fclose(f);
fclose(p);
}
remove("troupeaux.txt");
rename("temp.txt","troupeaux.txt");

}


void
on_modif_chercher_troupeau_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *id,*sortie;
GtkWidget *modifier_troupeau, *modification_troupeau;
char Id[20];

int trouv;
id = lookup_widget (objet, "modif2_id_troupeau");

strcpy(Id, gtk_entry_get_text(GTK_ENTRY(id)));
trouv=Chercher_troupeau (Id);

if (trouv==1)
{
sortie = lookup_widget(objet, "label36");
gtk_label_set_text(GTK_LABEL(sortie),"troupeau trouvée!");

}
else 
{
sortie = lookup_widget(objet, "label36");
gtk_label_set_text(GTK_LABEL(sortie),"Id introuvable!");

}
}


void
on_nombre_troupeau_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
        GtkWidget *menu_troupeaux, *fenetre_nombre_troupeau;

	menu_troupeaux=lookup_widget(objet,"menu_troupeaux");
	

	gtk_widget_destroy(menu_troupeaux);
	fenetre_nombre_troupeau=create_fenetre_nombre_troupeau();
	gtk_widget_show(fenetre_nombre_troupeau);
}


void
on_retour_menu5_troupeau_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_nombre_troupeau, *menu_troupeaux;

	fenetre_nombre_troupeau=lookup_widget(objet,"fenetre_nombre_troupeau");
	

	gtk_widget_destroy(fenetre_nombre_troupeau);
	menu_troupeaux=create_menu_troupeaux();
	gtk_widget_show(menu_troupeaux);
}


void
on_nombre_chercher_troupeau_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *typet,*sortie;
char Typet[20];

int trouv;
typet = lookup_widget (objet, "type_troupeau");

strcpy(Typet, gtk_entry_get_text(GTK_ENTRY(typet)));
trouv=Rechercher_troupeau ();

if (trouv==1)
{
sortie = lookup_widget(objet, "label41");
gtk_label_set_text(GTK_LABEL(sortie),"type troupeau trouvée!");

}
else 
{
sortie = lookup_widget(objet, "label41");
gtk_label_set_text(GTK_LABEL(sortie),"Type troupeau introuvable!");

}
}

