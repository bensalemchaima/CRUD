#include <gtk/gtk.h>

void
on_retour_vers_menu_troupeau_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_ajouter_troupeau_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_afficher_troupeau_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_troupeau_row_activated    (GtkTreeView     *treeview1_troupeau,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_troupeau_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_troupeaux_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_ajouter_troupeaux_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chercher_troupeaux_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_supprimer_troupeaux_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_troupeaux_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rechercher_troupeau_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_menu1_troupeau_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_troupeau_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_menu2_troupeau_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_modifier_troupeau_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_menu3_troupeau_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_menu4_troupeau_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_confirmer_troupeau_clicked (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modif_chercher_troupeau_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_nombre_troupeau_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_retour_menu5_troupeau_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_nombre_chercher_troupeau_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);
